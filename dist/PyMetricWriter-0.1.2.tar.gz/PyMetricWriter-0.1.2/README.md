# METRIC WRITER
This project is useful for write metrics *.prom file exported with node_exporter
